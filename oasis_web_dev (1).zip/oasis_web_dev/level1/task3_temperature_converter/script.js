// Temperature converter - vanilla JS
// Formulas: C->F = C*9/5+32 ; F->C = (F-32)*5/9 ; C->K = C+273.15
const tempInput = document.getElementById('temp');
const unitSelect = document.getElementById('unit');
const convertBtn = document.getElementById('convert');
const errorEl = document.getElementById('error');
const resultEl = document.getElementById('result');
const out = { C: document.getElementById('outC'), F: document.getElementById('outF'), K: document.getElementById('outK') };

const ABSOLUTE_ZERO_C = -273.15;

function toCelsius(value, unit) {
  if (unit === 'C') return value;
  if (unit === 'F') return (value - 32) * 5 / 9;
  return value - 273.15; // Kelvin
}

function fromCelsius(c, unit) {
  if (unit === 'C') return c;
  if (unit === 'F') return c * 9 / 5 + 32;
  return c + 273.15;
}

// Returns { ok: true, celsius } or { ok: false, message }
function validate(raw, unit) {
  const text = raw.trim();
  if (text === '') return { ok: false, message: 'Please enter a temperature value.' };
  if (!/^[-+]?\d*\.?\d+$/.test(text)) return { ok: false, message: 'Please enter a valid number (digits only).' };
  const celsius = toCelsius(parseFloat(text), unit);
  if (celsius < ABSOLUTE_ZERO_C - 1e-9) {
    return { ok: false, message: 'That is below absolute zero (-273.15 °C, -459.67 °F, 0 K). Please enter a higher value.' };
  }
  return { ok: true, celsius };
}

function showError(message) {
  errorEl.textContent = message;
  tempInput.classList.toggle('invalid', Boolean(message));
}

function format(n) { return (Math.round(n * 100) / 100).toString(); }

function convert() {
  const check = validate(tempInput.value, unitSelect.value);
  if (!check.ok) {
    showError(check.message);
    resultEl.hidden = true;
    return;
  }
  showError('');
  out.C.textContent = format(fromCelsius(check.celsius, 'C')) + ' °C';
  out.F.textContent = format(fromCelsius(check.celsius, 'F')) + ' °F';
  out.K.textContent = format(fromCelsius(check.celsius, 'K')) + ' K';
  resultEl.hidden = false;
}

convertBtn.addEventListener('click', convert);
tempInput.addEventListener('keydown', (e) => { if (e.key === 'Enter') convert(); });
unitSelect.addEventListener('change', () => { if (tempInput.value.trim() !== '') convert(); });

// real-time validation while typing
tempInput.addEventListener('input', () => {
  if (tempInput.value.trim() === '') { showError(''); resultEl.hidden = true; return; }
  const check = validate(tempInput.value, unitSelect.value);
  showError(check.ok ? '' : check.message);
  if (check.ok) convert();
});
