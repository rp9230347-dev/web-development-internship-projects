// To-Do app - vanilla JS with localStorage persistence
const STORAGE_KEY = 'todoTasksV1';
const form = document.getElementById('addForm');
const input = document.getElementById('taskInput');
const errorEl = document.getElementById('formError');
const pendingList = document.getElementById('pendingList');
const completedList = document.getElementById('completedList');
const pendingCount = document.getElementById('pendingCount');
const completedCount = document.getElementById('completedCount');

let tasks = load();
let editingId = null;

function load() {
  try { return JSON.parse(localStorage.getItem(STORAGE_KEY)) || []; }
  catch (e) { return []; }
}
function save() {
  try { localStorage.setItem(STORAGE_KEY, JSON.stringify(tasks)); } catch (e) { /* storage unavailable */ }
}
function stamp(ts) {
  return new Date(ts).toLocaleString([], { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' });
}

function addTask(text) {
  tasks.push({ id: Date.now() + Math.random(), text, done: false, added: Date.now(), completed: null });
  save(); render();
}
function toggleTask(id) {
  const t = tasks.find((x) => x.id === id);
  if (!t) return;
  t.done = !t.done;
  t.completed = t.done ? Date.now() : null;
  save(); render();
}
function deleteTask(id) {
  tasks = tasks.filter((x) => x.id !== id);
  save(); render();
}
function saveEdit(id, text) {
  const clean = text.trim();
  if (!clean) return;
  const t = tasks.find((x) => x.id === id);
  if (t) t.text = clean;
  editingId = null;
  save(); render();
}

function makeButton(label, cls, handler) {
  const b = document.createElement('button');
  b.type = 'button'; b.textContent = label; b.className = cls;
  b.addEventListener('click', handler);
  return b;
}

function buildItem(task) {
  const li = document.createElement('li');
  li.className = 'task' + (task.done ? ' completed' : '');

  const check = document.createElement('input');
  check.type = 'checkbox'; check.checked = task.done;
  check.title = 'Mark Complete';
  check.addEventListener('change', () => toggleTask(task.id));
  li.appendChild(check);

  if (editingId === task.id) {
    const edit = document.createElement('input');
    edit.type = 'text'; edit.value = task.text; edit.className = 'edit-input'; edit.maxLength = 120;
    edit.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') saveEdit(task.id, edit.value);
      if (e.key === 'Escape') { editingId = null; render(); }
    });
    li.appendChild(edit);
    const actions = document.createElement('div'); actions.className = 'actions';
    actions.append(
      makeButton('Save', 'save-btn', () => saveEdit(task.id, edit.value)),
      makeButton('Cancel', 'cancel-btn', () => { editingId = null; render(); })
    );
    li.appendChild(actions);
    setTimeout(() => edit.focus(), 0);
    return li;
  }

  const info = document.createElement('div'); info.className = 'info';
  const text = document.createElement('span'); text.className = 'text'; text.textContent = task.text;
  const time = document.createElement('span'); time.className = 'time';
  time.textContent = 'Added: ' + stamp(task.added) + (task.done && task.completed ? '  |  Completed: ' + stamp(task.completed) : '');
  info.append(text, time);
  li.appendChild(info);

  const actions = document.createElement('div'); actions.className = 'actions';
  actions.append(
    makeButton('Edit', 'edit-btn', () => { editingId = task.id; render(); }),
    makeButton('Delete', 'del-btn', () => deleteTask(task.id))
  );
  li.appendChild(actions);
  return li;
}

function fillList(list, items, emptyMessage) {
  list.innerHTML = '';
  if (items.length === 0) {
    const li = document.createElement('li');
    li.className = 'empty'; li.textContent = emptyMessage;
    list.appendChild(li);
    return;
  }
  items.forEach((t) => list.appendChild(buildItem(t)));
}

function render() {
  const pending = tasks.filter((t) => !t.done);
  const completed = tasks.filter((t) => t.done);
  pendingCount.textContent = pending.length + ' pending';
  completedCount.textContent = completed.length + ' completed';
  fillList(pendingList, pending, 'Nothing pending. Add a task above and get started!');
  fillList(completedList, completed, 'No completed tasks yet. You can do it!');
}

form.addEventListener('submit', (e) => {
  e.preventDefault();
  const text = input.value.trim();
  if (!text) { errorEl.textContent = 'Please type a task first.'; return; }
  errorEl.textContent = '';
  addTask(text);
  input.value = '';
  input.focus();
});
input.addEventListener('input', () => { errorEl.textContent = ''; });

render();
