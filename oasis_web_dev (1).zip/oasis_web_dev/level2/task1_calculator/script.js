// Calculator - own logic with variables and conditionals (no eval()).
// Operator chaining works left-to-right like a standard pocket calculator: 5 + 3 × 2 = 16.

const Calc = {
  current: '0',     // number currently being typed / shown
  previous: null,   // stored left-hand number
  operator: null,   // pending operator
  overwrite: false, // next digit should start a new number
  error: false,
  history: '',

  compute(a, b, op) {
    let r;
    if (op === '+') r = a + b;
    else if (op === '−') r = a - b;
    else if (op === '×') r = a * b;
    else if (op === '÷') {
      if (b === 0) throw new Error('Cannot divide by zero');
      r = a / b;
    }
    return parseFloat(r.toPrecision(12)); // avoids 0.1 + 0.2 = 0.30000000000000004
  },

  reset() {
    this.current = '0'; this.previous = null; this.operator = null;
    this.overwrite = false; this.error = false; this.history = '';
  },

  digit(d) {
    if (this.error) this.reset();
    if (this.overwrite) { this.current = d; this.overwrite = false; return; }
    if (this.current.replace('.', '').length >= 15) return;
    this.current = this.current === '0' ? d : this.current + d;
  },

  decimal() {
    if (this.error) this.reset();
    if (this.overwrite) { this.current = '0.'; this.overwrite = false; return; }
    if (!this.current.includes('.')) this.current += '.';
  },

  backspace() {
    if (this.error) { this.reset(); return; }
    if (this.overwrite) return;
    this.current = this.current.slice(0, -1);
    if (this.current === '' || this.current === '-') this.current = '0';
  },

  chooseOperator(op) {
    if (this.error) return;
    if (this.operator && this.overwrite) { // operator pressed twice -> replace it
      this.operator = op;
    } else {
      try {
        if (this.operator) this.previous = this.compute(this.previous, Number(this.current), this.operator);
        else this.previous = Number(this.current);
      } catch (e) { this.fail(e.message); return; }
      this.operator = op;
      this.current = String(this.previous);
      this.overwrite = true;
    }
    this.history = this.previous + ' ' + this.operator;
  },

  equals() {
    if (this.error || !this.operator) return;
    const b = Number(this.current);
    try {
      const result = this.compute(this.previous, b, this.operator);
      this.history = this.previous + ' ' + this.operator + ' ' + b + ' =';
      this.current = String(result);
      this.previous = null; this.operator = null; this.overwrite = true;
    } catch (e) { this.fail(e.message); }
  },

  fail(message) {
    this.reset(); this.error = true; this.current = message;
  },
};

if (typeof document !== 'undefined') {
  const screen = document.getElementById('screen');
  const historyEl = document.getElementById('history');
  const opButtons = document.querySelectorAll('[data-op]');

  function render() {
    screen.textContent = Calc.current;
    screen.classList.toggle('error', Calc.error);
    historyEl.textContent = Calc.history;
    opButtons.forEach((b) => b.classList.toggle('active', Boolean(Calc.operator) && Calc.overwrite && b.dataset.op === Calc.operator));
  }

  // event listeners attached to every button (no inline onclick)
  document.querySelectorAll('.key').forEach((btn) => {
    btn.addEventListener('click', () => {
      if (btn.dataset.digit !== undefined) Calc.digit(btn.dataset.digit);
      else if (btn.dataset.op) Calc.chooseOperator(btn.dataset.op);
      else if (btn.dataset.action === 'decimal') Calc.decimal();
      else if (btn.dataset.action === 'equals') Calc.equals();
      else if (btn.dataset.action === 'backspace') Calc.backspace();
      else if (btn.dataset.action === 'clear') Calc.reset();
      render();
    });
  });

  // keyboard support
  document.addEventListener('keydown', (e) => {
    const k = e.key;
    if (/^[0-9]$/.test(k)) Calc.digit(k);
    else if (k === '.') Calc.decimal();
    else if (k === '+') Calc.chooseOperator('+');
    else if (k === '-') Calc.chooseOperator('−');
    else if (k === '*') Calc.chooseOperator('×');
    else if (k === '/') { e.preventDefault(); Calc.chooseOperator('÷'); }
    else if (k === 'Enter' || k === '=') { e.preventDefault(); Calc.equals(); }
    else if (k === 'Backspace') Calc.backspace();
    else if (k === 'Escape') Calc.reset();
    else return;
    render();
  });
  render();
}

if (typeof module !== 'undefined') module.exports = Calc;
