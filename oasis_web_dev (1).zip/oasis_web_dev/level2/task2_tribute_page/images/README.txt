Add a royalty-free portrait here and name it kalam.jpg
Source: https://commons.wikimedia.org  (search "A. P. J. Abdul Kalam", pick a file with a free licence/public domain,
and keep the credit line in the page footer). Until then a grey placeholder avatar is shown automatically.
