// Front-end authentication demo (HTML + CSS + JS + localStorage)
// Users are stored in localStorage with a random salt and a SHA-256 hash (never plain text).
// Session lives in sessionStorage and is cleared on logout.
// NOTE: client-side auth is for learning only - real apps must authenticate on a server.

const USERS_KEY = 'authDemoUsers';
const SESSION_KEY = 'authDemoSession';

async function sha256(text) {
  if (!window.crypto || !window.crypto.subtle) {
    throw new Error('Secure hashing is not available. Open the page via https or localhost.');
  }
  const bytes = new TextEncoder().encode(text);
  const hash = await crypto.subtle.digest('SHA-256', bytes);
  return Array.from(new Uint8Array(hash)).map((b) => b.toString(16).padStart(2, '0')).join('');
}

function randomSalt() {
  const arr = new Uint8Array(16);
  crypto.getRandomValues(arr);
  return Array.from(arr).map((b) => b.toString(16).padStart(2, '0')).join('');
}

function getUsers() {
  try { return JSON.parse(localStorage.getItem(USERS_KEY)) || []; } catch (e) { return []; }
}
function saveUsers(users) { localStorage.setItem(USERS_KEY, JSON.stringify(users)); }

function validatePassword(pw) {
  if (pw.length < 8) return 'Password must be at least 8 characters long.';
  if (!/\d/.test(pw)) return 'Password must contain at least 1 number.';
  return '';
}

async function registerUser(username, email, password) {
  username = username.trim(); email = email.trim().toLowerCase();
  if (!username || !email || !password) return { ok: false, message: 'All fields are required.' };
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return { ok: false, message: 'Please enter a valid email address.' };
  const pwError = validatePassword(password);
  if (pwError) return { ok: false, message: pwError };

  const users = getUsers();
  const exists = users.some((u) => u.username.toLowerCase() === username.toLowerCase() || u.email === email);
  if (exists) return { ok: false, message: 'A user with this username or email already exists.' };

  const salt = randomSalt();
  users.push({ username, email, salt, hash: await sha256(salt + password) });
  saveUsers(users);
  return { ok: true };
}

async function loginUser(identifier, password) {
  const id = identifier.trim().toLowerCase();
  const user = getUsers().find((u) => u.username.toLowerCase() === id || u.email === id);
  const generic = { ok: false, message: 'Incorrect username/email or password.' }; // does not reveal which one is wrong
  if (!user) return generic;
  if ((await sha256(user.salt + password)) !== user.hash) return generic;
  sessionStorage.setItem(SESSION_KEY, JSON.stringify({ username: user.username, at: Date.now() }));
  return { ok: true };
}

function getSession() {
  try { return JSON.parse(sessionStorage.getItem(SESSION_KEY)); } catch (e) { return null; }
}
function logout() {
  sessionStorage.removeItem(SESSION_KEY);
  window.location.replace('index.html');
}
// Call at the top of protected pages
function requireLogin() {
  if (!getSession()) window.location.replace('index.html');
}
